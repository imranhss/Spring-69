package com.emranhss.CourierManagement.serviceimp;

import com.emranhss.CourierManagement.dto.response.PoliceStationResponseDTO;
import com.emranhss.CourierManagement.dto.mapper.PoliceStationMapper;
import com.emranhss.CourierManagement.entity.District;
import com.emranhss.CourierManagement.entity.PoliceStation;
import com.emranhss.CourierManagement.repository.DistrictRepository;
import com.emranhss.CourierManagement.repository.PoliceStationRepository;
import com.emranhss.CourierManagement.service.PoliceStationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PoliceStationServiceImpl implements PoliceStationService {

    @Autowired
    private PoliceStationRepository stationRepository;

    @Autowired
    private DistrictRepository districtRepository;



    @Override
    public PoliceStation save(PoliceStation p) {
        Long districtId= p.getDistrict().getId();
        District d= districtRepository.findById(districtId)
                .orElseThrow(()-> new RuntimeException("District Not found with this ID"));

         p.setDistrict(d);

        return stationRepository.save(p);
    }

    @Override
    public List<PoliceStation> findAll() {
        return stationRepository.findAll();
    }

    @Override
    public Optional<PoliceStation> getById(Long id) {
        return stationRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        stationRepository.deleteById(id);
    }

    @Override
    public List<PoliceStationResponseDTO> findByDistrictId(Long districtId) {
        List<PoliceStation> list= stationRepository.findByDistrictId(districtId);
        return list.stream().map(PoliceStationMapper::toDTO).collect(Collectors.toList());
    }



    @Override
    public List<PoliceStationResponseDTO> findByDistrictName(String districtName) {
        List<PoliceStation> list= stationRepository.findByDistrictName(districtName);
        return list.stream().map(PoliceStationMapper::toDTO).collect(Collectors.toList());
    }

    @Override
    public List<PoliceStationResponseDTO> search(String keyword) {

        return stationRepository
                .findAll()
                .stream()
                .filter(p ->
                        p.getName().toLowerCase().contains(keyword.toLowerCase()) ||
                                p.getNameBn().contains(keyword) ||
                                p.getPostalCode().contains(keyword)
                )
                .map(PoliceStationMapper::toDTO)
                .toList();
    }




}
