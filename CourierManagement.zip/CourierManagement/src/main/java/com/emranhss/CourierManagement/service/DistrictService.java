package com.emranhss.CourierManagement.service;

import com.emranhss.CourierManagement.dto.response.DistrictResponseDTO;
import com.emranhss.CourierManagement.entity.District;

import java.util.List;
import java.util.Optional;

public interface DistrictService {

    District save(District d);
    List<District> findAll();
    Optional<District> getById(Long id);
    void delete(Long id);
    District update(Long id, District district);

    List<DistrictResponseDTO> findByDivisionId(Long  divisionId);

    List<DistrictResponseDTO> findByDivisionName(String divisionName);


}
