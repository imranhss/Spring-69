package com.emranhss.CourierManagement.serviceimp;

import com.emranhss.CourierManagement.dto.response.DivisionResponseDTO;
import com.emranhss.CourierManagement.dto.mapper.DivisionMapper;
import com.emranhss.CourierManagement.entity.Country;
import com.emranhss.CourierManagement.entity.Division;
import com.emranhss.CourierManagement.repository.CountryRepository;
import com.emranhss.CourierManagement.repository.DivisionRepository;
import com.emranhss.CourierManagement.service.DivisionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class DivisionServiceImp implements DivisionService {

    @Autowired
    private DivisionRepository divisionRepository;

    @Autowired
    private CountryRepository countryRepository;



    @Override
    public Division save(Division d) {

        Long countryId = d.getCountry().getId();
        Country c = countryRepository.findById(countryId)
                .orElseThrow(()-> new RuntimeException("Country not found with this ID"));

        d.setCountry(c);
        return divisionRepository.save(d);
    }

    @Override
    public List<Division> findAll() {
        return divisionRepository.findAll();
    }

    @Override
    public Optional<Division> getById(Long id) {
        return divisionRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        divisionRepository.deleteById(id);
    }

    // Then your two methods become:
    @Override
    public List<DivisionResponseDTO> getDivisionsByCountryId(Long countryId) {
        return divisionRepository.findByCountryId(countryId)
                .stream()
                .map(DivisionMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<DivisionResponseDTO> getDivisionsByCountryName(String countryName) {
        return divisionRepository.findByCountryName(countryName)
                .stream()
                .map(DivisionMapper::toDTO)
                .collect(Collectors.toList());
    }


    @Override
    public Division update(Long id, Division division) {

        Division existing = divisionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Division not found"));

        existing.setName(division.getName());
        existing.setNameBn(division.getNameBn());
        existing.setActive(division.getActive());

        return divisionRepository.save(existing);
    }





}
